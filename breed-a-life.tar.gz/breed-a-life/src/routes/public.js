'use strict';
const config = require('../config');
const { all, get, run } = require('../db');
const auth = require('../auth');
const readers = require('../readers');
const resets = require('../resets');
const mailer = require('../mailer');
const settings = require('../settings');
const { HttpError, json, html, text, redirect, send, readBody, sendFromDir, sendFile } = require('../http');
const pages = require('../views/pages');
const { escapeHtml: esc, truncate, stripHtml, nowIso, toInt } = require('../util');
const path = require('path');
const fs = require('fs');

const BOT = /bot|crawl|spider|slurp|preview|facebookexternalhit|headless|lighthouse|monitor|uptime|curl|wget|python|axios|node-fetch|go-http|java\//i;
const PUBLISHED = "p.status = 'published' AND p.published_at <= ?";
const CARD_COLS = `p.id, p.title, p.slug, p.excerpt, p.category, p.tags, p.published_at, m.filename AS cover_filename`;
const FROM = 'FROM posts p LEFT JOIN media m ON m.id = p.cover_id';
const subscribeLimiter = auth.createLimiter(6, 60 * 60 * 1000);
const contactLimiter = auth.createLimiter(5, 60 * 60 * 1000);

const isAdmin = (ctx) => !!auth.userFromToken(ctx.cookies[auth.COOKIE]);

function recordView(ctx, pathname, postId) {
  if (ctx.method !== 'GET' || BOT.test(ctx.req.headers['user-agent'] || '') || isAdmin(ctx)) return;
  const day = nowIso().slice(0, 10);
  try {
    run('INSERT INTO page_views (day, path, count) VALUES (?,?,1) ON CONFLICT(day, path) DO UPDATE SET count = count + 1', day, pathname.slice(0, 200));
    if (postId) run('UPDATE posts SET views = views + 1 WHERE id = ?', postId);
  } catch { /* analytics must never break a page */ }
}

function gate(ctx) {
  if (settings.flag('maintenance_mode') && !isAdmin(ctx)) {
    ctx.res.setHeader('Retry-After', '3600');
    html(ctx, pages.maintenance(ctx), 503);
    return true;
  }
  return false;
}
function moduleOff(key) {
  if (!settings.flag(key)) throw new HttpError(404, 'This page is not available.');
}

function listPosts(where, params, limit, offset = 0) {
  const w = where ? `AND ${where}` : '';
  return all(`SELECT ${CARD_COLS} ${FROM} WHERE ${PUBLISHED} ${w} ORDER BY p.published_at DESC, p.id DESC LIMIT ? OFFSET ?`, nowIso(), ...params, limit, offset);
}

async function errorPage(ctx, status, textMsg) {
  const heading = status === 404 ? 'Page not found' : status === 403 ? 'Not allowed' : status === 405 ? 'Method not allowed' : 'Something went wrong';
  ctx.res.setHeader('Cache-Control', 'no-store');
  const body = pages.message(ctx, { status: String(status), heading, text: status === 404 ? 'The page you were looking for has moved, been removed, or never existed.' : textMsg });
  html(ctx, body, status);
}
async function notFound(ctx) {
  if (ctx.pathname.startsWith('/api/')) return json(ctx, { error: 'Not found.' }, 404);
  return errorPage(ctx, 404);
}

function parseForm(buf) {
  const out = {};
  for (const [k, v] of new URLSearchParams(buf.toString('utf8'))) out[k] = v;
  return out;
}

// A new version string whenever any public file changes, so phones refresh their saved copy.
function swVersion() {
  const crypto = require('crypto'); const h = crypto.createHash('sha1');
  const walk = (d) => { for (const f of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, f.name); if (f.isDirectory()) walk(p); else h.update(p + fs.statSync(p).mtimeMs); } };
  try { walk(config.publicDir); } catch { /* ignore */ }
  return h.digest('hex').slice(0, 10);
}
function offlinePage(ctx) {
  const t = esc(settings.get('site_title'));
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>You are offline | ${t}</title><meta name="theme-color" content="#0e1b57"><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0e1b57;color:#f4f2ec;font:18px/1.6 Georgia,serif;text-align:center;padding:24px}main{max-width:30rem}h1{font-weight:400;font-size:2rem;margin:.2em 0}p{opacity:.9}a{display:inline-block;margin-top:1rem;padding:.7em 1.4em;background:#e3c06a;color:#0e1b57;text-decoration:none;border-radius:4px;font-weight:600}em{display:block;margin-top:1.6rem;opacity:.8}</style></head><body><main><h1>You are offline</h1><p>This page has not been saved on your phone yet. Reconnect to read it. Pages you opened before are still available.</p><a href="/" onclick="location.reload();return false">Try again</a><em>"I have planted, Apollos watered; but God gave the increase." 1 Corinthians 3:6</em></main></body></html>`;
}

function register(router) {
  /* ----- static ----- */
  router.get('/uploads/:file', (ctx) => {
    const headers = /\.svg$/i.test(ctx.params.file) ? { 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; sandbox" } : {};
    if (ctx.query.download) {   // "Download" buttons: save the file under its readable title
      const row = get('SELECT title, original_name FROM media WHERE filename = ? AND visible = 1', ctx.params.file);
      if (row) {
        const ext = path.extname(ctx.params.file);
        const name = (require('../util').slugify(row.title || '', 60) || 'download') + ext;
        headers['Content-Disposition'] = `attachment; filename="${name}"`;
      }
    }
    return sendFromDir(ctx, config.uploadDir, ctx.params.file, { cache: 'public, max-age=31536000, immutable', headers });
  });
  router.get('/assets/:dir/:file', (ctx) => {
    if (!['css', 'js', 'img'].includes(ctx.params.dir)) throw new HttpError(404, 'Not found.');
    return sendFromDir(ctx, config.publicDir, `${ctx.params.dir}/${ctx.params.file}`, { cache: 'no-cache' });
  });
  router.get('/favicon.svg', (ctx) => sendFile(ctx, path.join(config.publicDir, 'favicon.svg'), { cache: 'public, max-age=86400' }));
  router.get('/favicon.ico', (ctx) => redirect(ctx, '/favicon.svg', 301));

  /* ----- progressive web app ----- */
  router.get('/apple-touch-icon.png', (ctx) => sendFile(ctx, path.join(config.publicDir, 'img/apple-touch-icon.png'), { cache: 'public, max-age=86400' }));
  router.get('/manifest.webmanifest', (ctx) => {
    const s = settings.getAll();
    const m = {
      id: '/', name: s.site_title, short_name: String(s.site_title).slice(0, 12), description: s.site_description,
      start_url: '/?source=pwa', scope: '/', display: 'standalone', orientation: 'portrait-primary',
      background_color: '#f4f2ec', theme_color: '#0e1b57', lang: 'en', categories: ['lifestyle', 'education', 'books'],
      icons: [
        { src: '/assets/img/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
        { src: '/assets/img/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
        { src: '/assets/img/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        { src: '/favicon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any' },
      ],
      shortcuts: [
        { name: 'My journal', short_name: 'Journal', url: '/journal', icons: [{ src: '/assets/img/icon-192.png', sizes: '192x192' }] },
        { name: 'Reflections', short_name: 'Read', url: '/blog', icons: [{ src: '/assets/img/icon-192.png', sizes: '192x192' }] },
      ],
    };
    send(ctx, 200, JSON.stringify(m), { 'Content-Type': 'application/manifest+json; charset=utf-8', 'Cache-Control': 'no-cache' });
  });
  // The service worker must be served from the site root so it can control every page.
  router.get('/sw.js', async (ctx) => {
    const src = await fs.promises.readFile(path.join(config.publicDir, 'js/sw.js'), 'utf8');
    send(ctx, 200, src.replace('__VERSION__', swVersion()), { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-cache', 'Service-Worker-Allowed': '/' });
  });
  router.get('/offline', (ctx) => send(ctx, 200, offlinePage(ctx), { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' }));

  /* ----- legacy URLs from the original static site (permanent redirects keep SEO value) ----- */
  const legacy = { '/index.html': '/', '/reflections.html': '/blog', '/gallery.html': '/gallery', '/videos.html': '/videos',
    '/post-independence-from-god.html': '/post/independence-from-god-has-never-turned-out-good-for-man' };
  for (const [from, to] of Object.entries(legacy)) router.get(from, (ctx) => redirect(ctx, to, 301));

  /* ----- SEO files ----- */
  router.get('/robots.txt', (ctx) => {
    const base = settings.baseUrl(ctx);
    text(ctx, `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api/\n\nSitemap: ${base}/sitemap.xml\n`);
  });

  router.get('/sitemap.xml', (ctx) => {
    const base = settings.baseUrl(ctx);
    const now = nowIso();
    const urls = [{ loc: '/', pri: '1.0', freq: 'weekly' }, { loc: '/blog', pri: '0.9', freq: 'weekly' }, { loc: '/about', pri: '0.5', freq: 'yearly' }];
    if (settings.get('quiet_time_html').trim()) urls.push({ loc: '/quiet-time', pri: '0.7', freq: 'monthly' });
    if (settings.flag('enable_gallery')) urls.push({ loc: '/gallery', pri: '0.6', freq: 'monthly' });
    if (settings.flag('enable_videos')) urls.push({ loc: '/videos', pri: '0.6', freq: 'monthly' });
    for (const m of all("SELECT id, title, kind, created_at FROM media WHERE visible = 1 AND ((kind = 'image' AND ?) OR (kind = 'video' AND ?)) ORDER BY id DESC LIMIT 500", settings.flag('enable_gallery') ? 1 : 0, settings.flag('enable_videos') ? 1 : 0)) urls.push({ loc: pages.mediaPath(m), pri: '0.5', freq: 'yearly', lastmod: m.created_at });
    if (settings.flag('enable_contact')) urls.push({ loc: '/contact', pri: '0.5', freq: 'yearly' });
    if (settings.flag('enable_donations')) urls.push({ loc: '/donate', pri: '0.5', freq: 'yearly' });
    for (const p of all('SELECT slug, updated_at FROM posts WHERE status = \'published\' AND published_at <= ? ORDER BY published_at DESC', now)) {
      urls.push({ loc: `/post/${p.slug}`, pri: '0.8', freq: 'monthly', mod: p.updated_at });
    }
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((u) => `  <url><loc>${esc(base + u.loc)}</loc>${u.mod ? `<lastmod>${u.mod.slice(0, 10)}</lastmod>` : ''}<changefreq>${u.freq}</changefreq><priority>${u.pri}</priority></url>`).join('\n')}\n</urlset>\n`;
    text(ctx, xml, 'application/xml; charset=utf-8');
  });

  router.get('/feed.xml', (ctx) => {
    const s = settings.getAll();
    const base = settings.baseUrl(ctx);
    const rows = all(`SELECT p.*, m.filename AS cover_filename ${FROM} WHERE ${PUBLISHED} ORDER BY p.published_at DESC LIMIT 20`, nowIso());
    const items = rows.map((p) => {
      const content = p.content.replace(/(src|href)="\/(?!\/)/g, `$1="${base}/`).replace(/]]>/g, ']]&gt;');
      return `    <item>
      <title>${esc(p.title)}</title>
      <link>${esc(base)}/post/${esc(p.slug)}</link>
      <guid isPermaLink="true">${esc(base)}/post/${esc(p.slug)}</guid>
      <pubDate>${new Date(p.published_at).toUTCString()}</pubDate>
      ${p.category ? `<category>${esc(p.category)}</category>` : ''}
      <description>${esc(truncate(p.excerpt || stripHtml(p.content), 300))}</description>
      <content:encoded><![CDATA[${content}]]></content:encoded>
    </item>`;
    }).join('\n');
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>${esc(s.site_title)}</title>
    <link>${esc(base)}/</link>
    <description>${esc(s.site_description)}</description>
    <language>en-us</language>
    <atom:link href="${esc(base)}/feed.xml" rel="self" type="application/rss+xml"/>
${items}
  </channel>
</rss>\n`;
    text(ctx, xml, 'application/rss+xml; charset=utf-8');
  });

  /* ----- newsletter ----- */
  router.post('/subscribe', async (ctx) => {
    const wantsJson = /application\/json/.test(ctx.req.headers['content-type'] || '') || ctx.req.headers['x-requested-with'] === 'fetch';
    const raw = await readBody(ctx.req, 8 * 1024);
    let data = {};
    try { data = wantsJson ? JSON.parse(raw.toString('utf8') || '{}') : parseForm(raw); } catch { data = {}; }
    const reply = (status, ok, message) => (wantsJson ? json(ctx, { ok, message }, status) : redirect(ctx, `/?subscribed=${ok ? 1 : 0}#subscribe`, 303));
    if (!settings.flag('enable_newsletter')) return reply(404, false, 'Subscriptions are closed.');
    if (data.website) return reply(200, true, 'Thank you for subscribing.'); // honeypot
    const gate_ = subscribeLimiter.take(ctx.ip);
    if (!gate_.allowed) return reply(429, false, 'Too many attempts. Please try again later.');
    const email = String(data.email || '').trim().toLowerCase().slice(0, 200);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return reply(422, false, 'Please enter a valid email address.');
    run('INSERT OR IGNORE INTO subscribers (email, created_at) VALUES (?, ?)', email, nowIso());
    return reply(200, true, 'Thank you. You are subscribed.');
  });

  /* ----- pages ----- */
  router.get('/', (ctx) => {
    if (gate(ctx)) return;
    const now = nowIso();
    const featured = get(`SELECT ${CARD_COLS} ${FROM} WHERE ${PUBLISHED} AND p.featured = 1 ORDER BY p.published_at DESC LIMIT 1`, now)
      || get(`SELECT ${CARD_COLS} ${FROM} WHERE ${PUBLISHED} ORDER BY p.published_at DESC LIMIT 1`, now);
    const latest = featured ? listPosts('p.id != ?', [featured.id], 6) : [];
    const images = settings.flag('enable_gallery') ? all("SELECT * FROM media WHERE kind = 'image' AND visible = 1 ORDER BY created_at DESC, id DESC LIMIT 6") : [];
    const videos = settings.flag('enable_videos') ? all("SELECT * FROM media WHERE kind = 'video' AND visible = 1 ORDER BY created_at DESC, id DESC LIMIT 2") : [];
    recordView(ctx, '/');
    html(ctx, pages.home(ctx, { featured, latest, images, videos }));
  });

  router.get('/blog', (ctx) => {
    if (gate(ctx)) return;
    const per = toInt(settings.get('posts_per_page'), 9);
    const page = Math.max(1, toInt(ctx.query.page, 1));
    const q = String(ctx.query.q || '').trim().slice(0, 100);
    const category = String(ctx.query.category || '').trim().slice(0, 60);
    const tag = String(ctx.query.tag || '').trim().slice(0, 40);
    const where = [];
    const params = [];
    if (q) { where.push("(p.title LIKE ? ESCAPE '\\' OR p.excerpt LIKE ? ESCAPE '\\' OR p.content LIKE ? ESCAPE '\\' OR p.tags LIKE ? ESCAPE '\\' OR p.category LIKE ? ESCAPE '\\')"); const l = '%' + q.replace(/[\\%_]/g, (m) => '\\' + m) + '%'; params.push(l, l, l, l, l); }
    if (category) { where.push('p.category = ? COLLATE NOCASE'); params.push(category); }
    if (tag) { where.push("(',' || LOWER(p.tags) || ',') LIKE ? ESCAPE '\\'"); params.push('%,' + tag.toLowerCase().replace(/[\\%_]/g, (m) => '\\' + m) + ',%'); }
    const w = where.join(' AND ');
    const total = get(`SELECT COUNT(*) AS c ${FROM} WHERE ${PUBLISHED} ${w ? 'AND ' + w : ''}`, nowIso(), ...params).c;
    const pagesCount = Math.max(1, Math.ceil(total / per));
    const posts = listPosts(w, params, per, (Math.min(page, pagesCount) - 1) * per);
    const categories = all(`SELECT DISTINCT p.category FROM posts p WHERE ${PUBLISHED} AND p.category != '' ORDER BY p.category COLLATE NOCASE`, nowIso()).map((r) => r.category);
    recordView(ctx, '/blog');
    html(ctx, pages.blog(ctx, { posts, total, page: Math.min(page, pagesCount), pages: pagesCount, q, category, tag, categories }));
  });

  router.get('/post/:slug', (ctx) => {
    if (gate(ctx)) return;
    const preview = isAdmin(ctx) && ctx.query.preview === '1';
    const p = get(`SELECT p.*, m.filename AS cover_filename, m.alt AS cover_alt ${FROM} WHERE p.slug = ? ${preview ? '' : `AND ${PUBLISHED}`}`, ...(preview ? [ctx.params.slug] : [ctx.params.slug, nowIso()]));
    if (!p) throw new HttpError(404, 'Not found.');
    const when = p.published_at || p.created_at;
    const prev = get(`SELECT p.title, p.slug ${FROM} WHERE ${PUBLISHED} AND p.published_at > ? ORDER BY p.published_at ASC LIMIT 1`, nowIso(), when);
    const next = get(`SELECT p.title, p.slug ${FROM} WHERE ${PUBLISHED} AND p.published_at < ? ORDER BY p.published_at DESC LIMIT 1`, nowIso(), when);
    let related = [];
    if (p.category) related = listPosts('p.category = ? COLLATE NOCASE AND p.id != ?', [p.category, p.id], 3);
    if (related.length < 3) {
      const have = new Set([p.id, ...related.map((r) => r.id)]);
      related = related.concat(listPosts('', [], 6).filter((r) => !have.has(r.id))).slice(0, 3);
    }
    if (!preview) recordView(ctx, `/post/${p.slug}`, p.id);
    if (preview) ctx.res.setHeader('X-Robots-Tag', 'noindex');
    p.published_at = when;
    html(ctx, pages.post(ctx, { p, prev, next, related }));
  });

  router.get('/gallery', (ctx) => {
    if (gate(ctx)) return;
    moduleOff('enable_gallery');
    recordView(ctx, '/gallery');
    html(ctx, pages.gallery(ctx, { images: all("SELECT * FROM media WHERE kind = 'image' AND visible = 1 ORDER BY created_at DESC, id DESC") }));
  });

  /* ----- one page per picture / video, with download and share ----- */
  function mediaRoute(kind, flag) {
    return (ctx) => {
      moduleOff(flag);
      const id = toInt((ctx.params.slug.match(/^(\d+)/) || [])[1]);
      const m = id ? get('SELECT * FROM media WHERE id = ? AND kind = ? AND visible = 1', id, kind) : null;
      if (!m) throw new HttpError(404, 'That ' + (kind === 'video' ? 'video' : 'picture') + ' is not available.');
      const canon = pages.mediaPath(m);
      if (ctx.pathname !== canon) return redirect(ctx, canon, 301);
      recordView(ctx, canon);
      const prev = get("SELECT * FROM media WHERE kind = ? AND visible = 1 AND (created_at > ? OR (created_at = ? AND id > ?)) ORDER BY created_at ASC, id ASC LIMIT 1", kind, m.created_at, m.created_at, m.id);
      const next = get("SELECT * FROM media WHERE kind = ? AND visible = 1 AND (created_at < ? OR (created_at = ? AND id < ?)) ORDER BY created_at DESC, id DESC LIMIT 1", kind, m.created_at, m.created_at, m.id);
      const more = all('SELECT * FROM media WHERE kind = ? AND visible = 1 AND id != ? ORDER BY created_at DESC, id DESC LIMIT 6', kind, m.id);
      html(ctx, pages.mediaPage(ctx, m, { prev, next, more }));
    };
  }
  router.get('/gallery/:slug', mediaRoute('image', 'enable_gallery'));
  router.get('/videos/:slug', mediaRoute('video', 'enable_videos'));

  router.get('/videos', (ctx) => {
    if (gate(ctx)) return;
    moduleOff('enable_videos');
    recordView(ctx, '/videos');
    html(ctx, pages.videos(ctx, { videos: all("SELECT * FROM media WHERE kind = 'video' AND visible = 1 ORDER BY created_at DESC, id DESC") }));
  });

  /* ----- contact ----- */
  router.get('/contact', (ctx) => {
    if (gate(ctx)) return;
    moduleOff('enable_contact');
    recordView(ctx, '/contact');
    html(ctx, pages.contact(ctx));
  });

  router.post('/contact', async (ctx) => {
    const raw = await readBody(ctx.req, 32 * 1024);
    const wantsJson = /application\/json/.test(ctx.req.headers['content-type'] || '');
    let data = {};
    try { data = wantsJson ? JSON.parse(raw.toString('utf8') || '{}') : parseForm(raw); } catch { data = {}; }
    const reply = (status, ok, message) => (wantsJson ? json(ctx, { ok, message }, status) : redirect(ctx, `/contact?sent=${ok ? 1 : 0}`, 303));
    if (!settings.flag('enable_contact')) return reply(404, false, 'The contact form is closed.');
    if (data.website) return reply(200, true, 'Thank you. Your message has been sent.'); // honeypot
    const clean = (v, max) => String(v || '').replace(/\u0000/g, '').trim().slice(0, max);
    const name = clean(data.name, 100);
    const email = clean(data.email, 200).toLowerCase();
    const subject = clean(data.subject, 150).replace(/[\r\n]+/g, ' ');
    const topic = data.topic === 'counseling' ? 'counseling' : 'general';
    const message = clean(data.message, 5000);
    if (!name) return reply(422, false, 'Please tell us your name.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return reply(422, false, 'Please enter a valid email address so we can reply.');
    if (message.length < 10) return reply(422, false, 'Please write a little more. Your message is very short.');
    if (!contactLimiter.take(ctx.ip).allowed) return reply(429, false, 'You have sent several messages recently. Please try again later.');
    // Counseling requests go to the counseling email the owner chose, plus every active admin the owner
    // allowed to handle messages who set a counseling email. General messages go to the contact email.
    const recipients = new Set();
    if (topic === 'counseling') {
      const own = (settings.get('counsel_email') || '').trim();
      if (own) recipients.add(own.toLowerCase());
      for (const u of all("SELECT permissions, counsel_email FROM users WHERE role = 'admin' AND status = 'active' AND counsel_email != ''")) {
        let p = []; try { p = JSON.parse(u.permissions || '[]'); } catch { /* ignore */ }
        if (p.includes('messages')) recipients.add(u.counsel_email.toLowerCase());
      }
    }
    const fallback = (settings.get('contact_email') || '').trim();
    if (!recipients.size && fallback) recipients.add(fallback.toLowerCase());
    const r = run('INSERT INTO messages (name, email, subject, body, created_at, topic, routed_to) VALUES (?,?,?,?,?,?,?)', name, email, subject, message, nowIso(), topic, [...recipients].join(', '));
    const id = Number(r.lastInsertRowid);
    if (mailer.configured() && recipients.size) {
      const subj = `[${settings.get('site_title')}] ${topic === 'counseling' ? 'COUNSELING REQUEST: ' : ''}${subject || 'New message'} (from ${name})`;
      const text = `New ${topic === 'counseling' ? 'counseling request' : 'message'} from the ${settings.get('site_title')} contact form\n\nName:    ${name}\nEmail:   ${email}\nSubject: ${subject || '(none)'}\nSent:    ${nowIso()}\n\n${message}\n\n--\nReply to this email to answer ${name} directly.`;
      Promise.allSettled([...recipients].map((to) => mailer.send({ to, replyTo: email, subject: subj, text }))).then((rs) => {
        if (rs.some((x) => x.status === 'fulfilled')) run('UPDATE messages SET emailed = 1 WHERE id = ?', id);
        const bad = rs.find((x) => x.status === 'rejected');
        if (bad) run('UPDATE messages SET email_error = ? WHERE id = ?', String(bad.reason && bad.reason.message).slice(0, 300), id);
      });
    }
    return reply(201, true, 'Thank you. Your message has been sent.');
  });

  /* ----- donate ----- */
  router.get('/donate', (ctx) => {
    if (gate(ctx)) return;
    moduleOff('enable_donations');
    recordView(ctx, '/donate');
    html(ctx, pages.donate(ctx, { methods: all('SELECT * FROM donation_methods WHERE visible = 1 ORDER BY position, id') }));
  });

  /* ----- reader accounts: pages (the data itself comes from /api/reader/*) ----- */
  const safeNext = (v) => (typeof v === 'string' && /^\/(?!\/)[^\\\s]*$/.test(v) ? v : '');
  const accountsOn = () => { if (!settings.flag('enable_accounts')) throw new HttpError(404, 'This page is not available.'); };
  router.get('/join', (ctx) => {
    if (gate(ctx)) return; accountsOn();
    if (readers.current(ctx)) return redirect(ctx, safeNext(ctx.query.next) || '/journal');
    html(ctx, pages.join(ctx, { next: safeNext(ctx.query.next) }));
  });
  router.get('/signin', (ctx) => {
    if (gate(ctx)) return; accountsOn();
    if (readers.current(ctx)) return redirect(ctx, safeNext(ctx.query.next) || '/journal');
    html(ctx, pages.signin(ctx, { next: safeNext(ctx.query.next) }));
  });
  router.get('/forgot-password', (ctx) => {
    if (gate(ctx)) return; accountsOn();
    html(ctx, pages.forgot(ctx, { emailReady: mailer.configured() && !!resets.safeBase(ctx) }));
  });
  router.get('/reset-password', (ctx) => {
    if (gate(ctx)) return; accountsOn();
    ctx.res.setHeader('Referrer-Policy', 'no-referrer');
    const token = String(ctx.query.token || '');
    html(ctx, pages.reset(ctx, { token, valid: !!resets.find('reader', token) }));
  });
  router.get('/journal', (ctx) => {
    if (gate(ctx)) return; accountsOn();
    if (!readers.current(ctx)) return redirect(ctx, '/signin?next=/journal');
    html(ctx, pages.journal(ctx));
  });

  router.get('/quiet-time', (ctx) => {
    if (gate(ctx)) return;
    if (!settings.get('quiet_time_html').trim()) throw new HttpError(404, 'The Quiet Time guide has not been published yet.');
    recordView(ctx, '/quiet-time');
    html(ctx, pages.quietTime(ctx));
  });

  router.get('/about', (ctx) => {
    if (gate(ctx)) return;
    recordView(ctx, '/about');
    html(ctx, pages.about(ctx));
  });
}

module.exports = { register, notFound, errorPage };
