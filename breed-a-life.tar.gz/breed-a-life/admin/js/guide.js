/* Quiet Time guide editor: owner, or any admin given the "guide" permission. */
(function () {
  'use strict';
  var SX = window.SX, el = SX.el;
  SX.views.guide = function (ctx) {
    ctx.title('Quiet Time guide');
    return SX.api('GET', '/quiet-time').then(function (g) {
      var title = el('input', { type: 'text', maxlength: 120 }); title.value = g.title || '';
      var body = el('textarea', { rows: 18 }); body.value = g.html || '';
      var status = el('p', { class: 'hint', text: g.html ? 'Published. Visitors see a "Quiet time" link in the menu.' + (g.by ? ' Last saved by ' + g.by + '.' : '') : 'Not published yet. The page and its menu link stay hidden until you save some text.' });
      var save = SX.btn('Save and publish', { kind: 'primary', onClick: function (e) {
        var b = e.currentTarget; b.disabled = true;
        SX.api('PUT', '/quiet-time', { title: title.value, html: body.value }).then(function (r) {
          SX.toast(r.published ? 'Guide published' : 'Guide cleared and hidden', 'ok');
          status.textContent = r.published ? 'Published.' : 'Not published. Page hidden.';
        }).catch(function (err) { SX.toast(err.message, 'err'); }).then(function () { b.disabled = false; });
      } });
      var card = el('section', { class: 'card' }, [el('div', { class: 'card-h' }, el('h2', { text: 'Write the guide' })), el('div', { class: 'card-b' }, [
        el('p', { class: 'hint', text: 'Teach visitors how to do a quiet time. Use paragraphs like <p>...</p>, headings <h2>...</h2> and lists <ul><li>...</li></ul>. Unsafe markup is removed. Empty the box and save to hide the page again.' }),
        SX.field('Page title', title, '', 'g-title'), SX.field('Guide text (HTML)', body, '', 'g-body'), status, save])]);
      ctx.view.appendChild(card);
    });
  };
})();
