/* Dashboard shell: sign-in check, navigation, hash router. */
(function () {
  'use strict';
  var SX = window.SX, el = SX.el;
  var NAV = [
    ['', 'Overview', 'home', 'dashboard'], ['h', 'Content'], ['posts', 'Posts', 'doc', 'posts', 'posts'], ['pictures', 'Pictures', 'image', 'pictures', 'media'], ['videos', 'Videos', 'video', 'videos', 'media'], ['guide', 'Quiet Time guide', 'book', 'guide', 'guide'],
    ['h', 'Audience'], ['messages', 'Messages', 'mail', 'messages', 'messages'], ['readers', 'Readers', 'book', 'readers', 'readers'], ['subscribers', 'Subscribers', 'users', 'subscribers', 'readers'], ['giving', 'Giving', 'heart', 'giving', 'giving'],
    ['h', 'Website'], ['team', 'Team and access', 'lock', 'team', 'OWNER'], ['activity', 'Activity', 'list', 'activity', 'activity'], ['settings', 'Settings', 'gear', 'settings', 'settings'], ['database', 'Database', 'db', 'database', 'OWNER']
  ];
  var view = SX.$('#view'), actions = SX.$('#actions'), titleEl = SX.$('#title'), nav = SX.$('#nav'), side = SX.$('#side'), token = 0;

  SX.can = function (p) { var u = SX.user; if (!u) return false; if (p === 'OWNER') return u.role === 'owner'; return u.role === 'owner' || (u.permissions || []).indexOf(p) >= 0; };
  SX.refreshBadge = function () {
    if (!SX.can('messages')) return;
    SX.api('GET', '/messages?filter=unread&page=1').then(function (d) { var b = SX.$('#nav .badge'); if (b) { b.textContent = d.unread; b.hidden = !d.unread; } }).catch(function () {});
  };
  function drawNav(cur) {
    SX.clear(nav);
    NAV.forEach(function (n) {
      if (n[0] === 'h' && n.length === 2) { nav.appendChild(el('h6', { text: n[1] })); return; }
      if (n[4] && !SX.can(n[4])) return;
      var a = el('a', { href: '#/' + n[0], class: cur === n[3] ? 'on' : '', 'aria-current': cur === n[3] ? 'page' : null }, [SX.icon(n[2]), el('span', { text: n[1] })]);
      if (n[0] === 'messages') a.appendChild(el('span', { class: 'badge', hidden: true }));
      nav.appendChild(a);
    });
    SX.refreshBadge();
  }
  function route() {
    var hash = location.hash.replace(/^#\/?/, '').split('?')[0], parts = hash.split('/').filter(Boolean).map(decodeURIComponent);
    var key = parts[0] || '', params = parts.slice(1), name = key === '' ? 'dashboard' : key === 'posts' && params.length ? 'post' : key;
    var navKey = key === '' ? 'dashboard' : key;
    var fn = SX.views[name];
    var need = { posts: 'posts', post: 'posts', pictures: 'media', videos: 'media', messages: 'messages', readers: 'readers', subscribers: 'readers', giving: 'giving', team: 'OWNER', activity: 'activity', guide: 'guide', settings: 'settings', database: 'OWNER' }[name];
    if (need && !SX.can(need)) { name = 'denied'; fn = SX.views.denied; }
    side.classList.remove('open');
    if (!fn) { name = 'dashboard'; navKey = 'dashboard'; fn = SX.views.dashboard; }
    SX.dirtyGuard = null; drawNav(name === 'denied' ? '' : navKey); SX.clear(view); SX.clear(actions); var my = ++token;
    var ctx = { view: view, params: params, title: function (t) { titleEl.textContent = t; document.title = t + ' | Breed a Life'; }, actions: function (nodes) { SX.clear(actions); (nodes || []).forEach(function (n) { if (n) actions.appendChild(n); }); } };
    view.appendChild(SX.loading());
    Promise.resolve().then(function () { return fn(ctx); }).catch(function (e) { if (my === token) { SX.clear(view); view.appendChild(SX.empty('Something went wrong', e.message)); } });
    view.focus({ preventScroll: true }); window.scrollTo(0, 0);
  }
  var lastHash = location.hash;
  window.addEventListener('hashchange', function (e) {
    if (SX.dirtyGuard && SX.dirtyGuard() && !window.confirm('You have unsaved changes. Leave without saving?')) { history.replaceState(null, '', lastHash || '#/'); return; }
    lastHash = location.hash; route();
  });
  window.addEventListener('beforeunload', function (e) { if (SX.dirtyGuard && SX.dirtyGuard()) { e.preventDefault(); e.returnValue = ''; } });

  SX.drawWho = function () {
    var w = SX.$('#who'); SX.clear(w); w.appendChild(SX.icon('lock')); w.appendChild(el('span', { text: SX.user.username + (SX.user.role === 'owner' ? ' (owner)' : ' (admin)') }));
  };
  SX.$('#viewsite').appendChild(SX.icon('ext')); SX.$('#viewsite').appendChild(el('span', { text: 'View website' }));
  var lo = SX.$('#logout'); lo.appendChild(SX.icon('out')); lo.appendChild(el('span', { text: 'Sign out' }));
  lo.addEventListener('click', function () { SX.api('POST', '/logout', {}).catch(function () {}).then(function () { location.href = '/admin/login'; }); });
  var mb = SX.$('#menu'); mb.appendChild(SX.icon('menu')); mb.addEventListener('click', function () { side.classList.toggle('open'); });

  SX.api('GET', '/me').then(function (d) { SX.user = d.user; SX.drawWho(); route(); }).catch(function () {});
})();
