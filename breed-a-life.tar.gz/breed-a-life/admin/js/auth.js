/* Sign-in, forgot-password and reset-password pages for the dashboard. */
(function () {
  'use strict';
  var page = document.body.getAttribute('data-page'), f = document.getElementById('f'), msg = document.getElementById('msg'), btn = f.querySelector('button');
  var token = '';
  if (page === 'reset') {
    token = new URLSearchParams(location.search).get('token') || '';
    history.replaceState(null, '', location.pathname);   // keep the secret out of history and screenshots
    if (!token) { msg.className = 'msg err'; msg.textContent = 'This reset link is incomplete. Request a new one.'; btn.disabled = true; }
  }
  function say(t, ok) { msg.className = 'msg ' + (ok ? 'ok' : 'err'); msg.textContent = t; }
  function post(url, body) {
    return fetch('/api/admin' + url, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'sx-admin' }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (d) { if (!r.ok) throw new Error(d.error || 'Something went wrong. Please try again.'); return d; }); });
  }
  f.addEventListener('submit', function (e) {
    e.preventDefault(); var v = function (n) { return f.elements[n] ? f.elements[n].value : ''; };
    btn.disabled = true; say('', true);
    var req;
    if (page === 'login') req = post('/login', { username: v('username'), password: v('password'), remember: f.elements.remember.checked }).then(function () { location.href = '/admin'; });
    else if (page === 'forgot') req = post('/forgot', { identifier: v('identifier') }).then(function (d) { say(d.message, true); });
    else {
      if (v('password') !== v('confirm')) { say('The two passwords do not match.'); btn.disabled = false; return; }
      req = post('/reset', { token: token, password: v('password') }).then(function () { say('Password changed. Taking you to sign in…', true); setTimeout(function () { location.href = '/admin/login'; }, 1500); });
    }
    req.catch(function (err) { say(err.message); }).then(function () { if (page !== 'login' || msg.className.indexOf('err') >= 0) btn.disabled = false; });
  });
})();
