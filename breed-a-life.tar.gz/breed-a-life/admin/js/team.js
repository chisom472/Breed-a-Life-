/* Team and access (owner only), Activity log, and the "no access" screen. */
(function () {
  'use strict';
  var SX = window.SX, el = SX.el, fmt = SX.fmt;
  function fail(e) { SX.toast(e.message, 'err'); }

  SX.views.denied = function (ctx) {
    ctx.title('No access'); ctx.actions([]); SX.clear(ctx.view);
    ctx.view.appendChild(SX.empty('You do not have access to this page', 'The site owner decides what each admin can do. Ask them to enable it for you.'));
  };

  /* Checkbox list of permissions. Returns { node, values(), setAll(bool) } */
  function permBox(all, selected) {
    var boxes = {}, wrap = el('div', { class: 'perm-grid' });
    Object.keys(all).forEach(function (k) {
      var cb = el('input', { type: 'checkbox', id: 'perm-' + k }); cb.checked = selected.indexOf(k) >= 0; boxes[k] = cb;
      wrap.appendChild(el('label', { class: 'check', for: 'perm-' + k }, [cb, el('span', {}, [el('b', { text: k.charAt(0).toUpperCase() + k.slice(1) }), el('small', { class: 'hint', style: 'display:block', text: all[k] })])]));
    });
    var allBtn = SX.btn('Full control', { sm: true, onClick: function () { Object.keys(boxes).forEach(function (k) { boxes[k].checked = true; }); } });
    var noneBtn = SX.btn('Clear all', { sm: true, onClick: function () { Object.keys(boxes).forEach(function (k) { boxes[k].checked = false; }); } });
    return { node: el('div', {}, [el('div', { style: 'display:flex;gap:8px;margin-bottom:10px' }, [allBtn, noneBtn]), wrap]), values: function () { return Object.keys(boxes).filter(function (k) { return boxes[k].checked; }); } };
  }

  function editModal(a, perms, after) {
    var pb = permBox(perms, a ? a.permissions : []);
    var username = el('input', { type: 'text', value: a ? a.username : '', maxlength: 40, disabled: !!a, autocomplete: 'off' });
    var email = el('input', { type: 'email', value: a ? a.email : '', placeholder: 'their own email (used for password resets)' });
    var counsel = el('input', { type: 'email', value: a ? a.counsel_email : '', placeholder: 'optional: where counseling requests for them are sent' });
    var m = SX.modal({ title: a ? 'Access for ' + a.username : 'Add an admin', size: 'wide', body: el('div', {}, [
      SX.field('Username', username, a ? 'Usernames cannot be changed.' : 'Letters, numbers, dots, dashes.', 'ad-user'),
      SX.field('Email', email, 'Password reset links go here. It can be any email they choose.', 'ad-mail'),
      SX.field('Counseling email', counsel, 'If you tick Messages, counseling requests can be forwarded here too.', 'ad-couns'),
      el('div', { class: 'field' }, [el('span', { class: 'lbl', text: 'What this admin may do' }), pb.node]),
      el('p', { class: 'hint', text: 'Admins can never manage other admins, change email delivery, or open the database. Only you can.' })]),
      actions: [{ text: 'Cancel', onClick: function () { m.close(); } }, { text: a ? 'Save access' : 'Add admin', kind: 'primary', onClick: function () {
        var body = { email: email.value, counsel_email: counsel.value, permissions: pb.values() };
        if (!a) body.username = username.value;
        SX.api(a ? 'PUT' : 'POST', '/admins' + (a ? '/' + a.id : ''), body).then(function (d) {
          m.close(); after();
          if (!a) tempPassword(d.username, d.temporary_password);
          else SX.toast('Access saved', 'ok');
        }).catch(fail); } }] });
  }

  function tempPassword(name, pw) {
    var m = SX.modal({ title: 'Temporary password for ' + name, body: el('div', {}, [
      el('p', { style: 'margin-top:0', text: 'Give this to ' + name + ' privately (it is shown only once). They sign in at /admin and should change it under Settings > Account.' }),
      el('pre', { class: 'code', text: pw }), SX.btn('Copy', { sm: true, icon: 'link', onClick: function () { SX.copy(pw); } })]),
      actions: [{ text: 'Done', kind: 'primary', onClick: function () { m.close(); } }] });
  }

  SX.views.team = function (ctx) {
    ctx.title('Team and access');
    ctx.actions([SX.btn('Add admin', { kind: 'primary', icon: 'plus', onClick: function () { SX.api('GET', '/admins').then(function (d) { editModal(null, d.permissions, load); }).catch(fail); } })]);
    var view = ctx.view; SX.clear(view);
    var body = el('div');
    view.appendChild(el('div', { class: 'notice info' }, [SX.icon('lock'), el('div', { text: 'You are the owner. You decide who can write, upload, see readers, receive counseling requests and see donations. You can pause or remove any admin at any time, and every action they take is recorded in Activity.' })]));
    view.appendChild(el('section', { class: 'card' }, body));
    function load() {
      SX.api('GET', '/admins').then(function (d) {
        SX.clear(body);
        body.appendChild(el('ul', { class: 'list' }, d.items.map(function (a) {
          var isOwner = a.role === 'owner';
          return el('li', { style: 'align-items:flex-start;flex-wrap:wrap' }, [
            el('div', { style: 'flex:1;min-width:220px' }, [
              el('div', { class: 't' }, [a.username + ' ', el('span', { class: 'chip ' + (isOwner ? 'info' : a.status === 'active' ? 'ok' : 'warn'), text: isOwner ? 'Owner' : a.status === 'active' ? 'Admin' : 'Paused' })]),
              el('div', { class: 'hint', text: [a.email, a.last_login ? 'last seen ' + fmt.ago(a.last_login) : 'never signed in'].filter(Boolean).join(' · ') }),
              el('div', { class: 'hint', text: isOwner ? 'Full control' : (a.permissions.length ? 'Can: ' + a.permissions.join(', ') : 'No access yet. Tick what they may do.') })]),
            isOwner ? null : el('div', { style: 'display:flex;gap:6px;flex-wrap:wrap' }, [
              SX.btn('Access', { sm: true, icon: 'edit', onClick: function () { editModal(a, d.permissions, load); } }),
              SX.btn(a.status === 'active' ? 'Pause' : 'Resume', { sm: true, onClick: function () { SX.api('PUT', '/admins/' + a.id, { status: a.status === 'active' ? 'suspended' : 'active' }).then(function () { SX.toast(a.status === 'active' ? 'Paused. They are signed out.' : 'Resumed', 'ok'); load(); }).catch(fail); } }),
              SX.btn('New password', { sm: true, icon: 'key', onClick: function () { SX.api('POST', '/admins/' + a.id + '/reset', {}).then(function (r) { tempPassword(a.username, r.temporary_password); }).catch(fail); } }),
              SX.btn('', { sm: true, kind: 'ghost', icon: 'trash', title: 'Remove', onClick: function () { SX.confirm({ title: 'Remove ' + a.username + '?', message: 'They lose all access immediately. Their articles and uploads stay on the site.', confirmText: 'Remove admin', danger: true }).then(function (ok) { if (ok) SX.api('DELETE', '/admins/' + a.id).then(function () { SX.toast('Admin removed', 'ok'); load(); }).catch(fail); }); } })])]);
        })));
      }).catch(function (e) { SX.clear(body); body.appendChild(SX.empty('Could not load', e.message)); });
    }
    load();
  };

  /* ---------- Activity: admins and readers ---------- */
  SX.views.activity = function (ctx) {
    ctx.title('Activity'); ctx.actions([]);
    var st = { page: 1, who: '', q: '' }, view = ctx.view; SX.clear(view);
    var body = el('div'), pager = el('div');
    var who = el('select', { 'aria-label': 'Filter by person', style: 'width:auto' }, [el('option', { value: '', text: 'Everyone' }), el('option', { value: 'admins', text: 'Admins' }), el('option', { value: 'readers', text: 'Readers' }), el('option', { value: 'system', text: 'System' })]);
    who.addEventListener('change', function () { st.who = who.value; st.page = 1; load(); });
    view.appendChild(el('div', { class: 'toolbar' }, [SX.searchBox('Search activity', function (q) { st.q = q; st.page = 1; load(); }), who]));
    view.appendChild(el('section', { class: 'card' }, body)); view.appendChild(pager);
    function load() {
      SX.api('GET', '/activity?page=' + st.page + (st.who ? '&who=' + st.who : '') + (st.q ? '&q=' + encodeURIComponent(st.q) : '')).then(function (d) {
        SX.clear(body); SX.clear(pager);
        if (!d.items.length) { body.appendChild(SX.empty('Nothing here yet')); return; }
        body.appendChild(el('div', { class: 'table-wrap' }, el('table', { class: 't' }, [el('thead', {}, el('tr', {}, ['When', 'Who', 'What', 'Details'].map(function (h) { return el('th', { text: h }); }))), el('tbody', {}, d.items.map(function (a) {
          return el('tr', {}, [el('td', { style: 'white-space:nowrap', text: fmt.dt(a.ts) }), el('td', {}, el('span', { class: 'chip', text: a.actor })), el('td', { text: SX.actionLabel(a.action) }), el('td', { class: 'cell-trunc', text: a.detail || '' })]); }))])));
        pager.appendChild(SX.pager(d.page, d.pages, d.total, function (p) { st.page = p; load(); }, 'events'));
      }).catch(function (e) { SX.clear(body); body.appendChild(SX.empty('Could not load', e.message)); });
    }
    load();
  };
})();
