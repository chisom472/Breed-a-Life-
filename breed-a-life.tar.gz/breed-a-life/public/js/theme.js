/* Applies the visitor's chosen colour theme before the page paints (no flash). */
(function () {
  try {
    var t = localStorage.getItem('ba-theme');
    if (t && /^(lapis|forest|sunrise|rose|night|auto)$/.test(t)) {
      if (t === 'auto') t = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'night' : document.documentElement.getAttribute('data-theme');
      document.documentElement.setAttribute('data-theme', t);
    }
  } catch (e) { /* storage blocked: keep the site default */ }
})();
