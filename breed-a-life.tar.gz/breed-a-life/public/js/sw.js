/* Service worker: makes the site installable and lets pages you have already opened work offline.
   Safe by design: it never stores sign-in pages, the dashboard, reader notes or API responses. */
'use strict';
const VERSION = '__VERSION__';
const CORE = 'core-' + VERSION;
const RUNTIME = 'runtime-v1';
const PRECACHE = ['/offline', '/assets/css/site.css', '/assets/js/site.js', '/assets/js/reader.js', '/favicon.svg', '/assets/img/icon-192.png'];
// Public reading pages that may be kept for offline use.
const PAGES = /^\/(?:$|blog|post\/|gallery|videos|about|quiet-time|study|contact|donate|media\/)/;
const NEVER = /^\/(?:api|admin|journal|join|signin|forgot-password|reset-password|sw\.js)/;

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CORE).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k.startsWith('core-') && k !== CORE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()));
});

async function trim(name, max) {
  const c = await caches.open(name); const keys = await c.keys();
  for (let i = 0; i < keys.length - max; i++) await c.delete(keys[i]);
}

self.addEventListener('fetch', (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== self.location.origin || req.headers.has('range') || NEVER.test(url.pathname)) return;

  // Pages: network first, fall back to the saved copy, then to the offline page.
  if (req.mode === 'navigate') {
    e.respondWith((async () => {
      try {
        const res = await fetch(req);
        if (res.ok && PAGES.test(url.pathname) && !url.search.includes('preview')) {
          const copy = res.clone(); caches.open(RUNTIME).then((c) => c.put(req, copy)).then(() => trim(RUNTIME, 80));
        }
        return res;
      } catch {
        return (await caches.match(req)) || (await caches.match('/offline')) || Response.error();
      }
    })());
    return;
  }

  // Styles, scripts, icons and pictures: show the saved copy at once, refresh it in the background.
  if (/^\/(?:assets|uploads|favicon|apple-touch)/.test(url.pathname) && !/\.(mp4|webm|mov|ogv|mp3|m4a|ogg|wav)$/i.test(url.pathname)) {
    e.respondWith((async () => {
      const cached = await caches.match(req);
      const net = fetch(req).then((res) => {
        if (res.ok) { const copy = res.clone(); caches.open(RUNTIME).then((c) => c.put(req, copy)).then(() => trim(RUNTIME, 80)); }
        return res;
      }).catch(() => cached);
      return cached || net;
    })());
  }
});
