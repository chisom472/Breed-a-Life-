(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* mobile navigation */
  var toggle = $('.nav-toggle'), nav = $('#site-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  /* newsletter */
  $$('[data-subscribe]').forEach(function (form) {
    var msg = $('.subscribe-msg', form);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = $('button', form);
      btn.disabled = true;
      fetch('/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
        body: JSON.stringify({ email: form.email.value, website: form.website.value })
      }).then(function (r) { return r.json(); }).then(function (d) {
        msg.textContent = d.message || 'Thank you.';
        if (d.ok) form.email.value = '';
      }).catch(function () { msg.textContent = 'Something went wrong. Please try again.'; })
        .then(function () { btn.disabled = false; });
    });
  });
  if (/[?&]subscribed=/.test(location.search)) {
    var m = $('.subscribe-msg');
    if (m) m.textContent = /subscribed=1/.test(location.search) ? 'Thank you. You are subscribed.' : 'That address could not be added. Please try again.';
  }

  /* YouTube click-to-load (no third-party requests until played) */
  $$('[data-yt]').forEach(function (frame) {
    var btn = $('.yt-play', frame);
    if (!btn) return;
    btn.addEventListener('click', function () {
      var f = document.createElement('iframe');
      f.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(frame.getAttribute('data-yt')) + '?autoplay=1&rel=0';
      f.title = frame.getAttribute('data-title') || 'Video';
      f.allow = 'accelerometer; autoplay; encrypted-media; picture-in-picture; fullscreen';
      f.allowFullscreen = true;
      f.referrerPolicy = 'strict-origin-when-cross-origin';
      frame.replaceChildren(f);
    });
  });

  /* reading progress */
  var bar = $('.read-progress span'), post = $('.post .prose');
  if (bar && post) {
    var tick = false;
    var update = function () {
      var r = post.getBoundingClientRect();
      var total = r.height - window.innerHeight * 0.6;
      var done = Math.min(1, Math.max(0, (-r.top + window.innerHeight * 0.2) / Math.max(total, 1)));
      bar.style.width = (done * 100).toFixed(1) + '%';
      tick = false;
    };
    window.addEventListener('scroll', function () { if (!tick) { tick = true; requestAnimationFrame(update); } }, { passive: true });
    update();
  }

  /* copy link */
  $$('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var url = b.getAttribute('data-copy');
      var done = function () { var t = b.textContent; b.textContent = 'Copied'; setTimeout(function () { b.textContent = t; }, 1600); };
      if (navigator.clipboard) navigator.clipboard.writeText(url).then(done); else { window.prompt('Copy this link', url); }
    });
  });

  /* share a picture or video page: native share sheet, else copy the link */
  $$('[data-share-page]').forEach(function (b) {
    b.addEventListener('click', function () {
      var data = { title: b.getAttribute('data-title'), url: b.getAttribute('data-url') };
      var note = $('[data-share-note]');
      var say = function (t) { if (note) note.textContent = t; };
      if (navigator.share) { navigator.share(data).catch(function () {}); }
      else if (navigator.clipboard) { navigator.clipboard.writeText(data.url).then(function () { say('Link copied.'); }); }
      else { window.prompt('Copy this link', data.url); }
    });
  });

  /* gallery lightbox */
  var lb = $('[data-lightbox]');
  if (lb) {
    var items = $$('.g-open'), idx = 0, lastFocus = null;
    var img = $('[data-lb-img]', lb), cap = $('[data-lb-cap]', lb);
    var show = function (i) {
      idx = (i + items.length) % items.length;
      var src = $('img', items[idx]);
      img.src = src.currentSrc || src.src;
      img.alt = src.alt;
      cap.textContent = '';
      if (src.dataset.title) { var s = document.createElement('strong'); s.textContent = src.dataset.title; cap.appendChild(s); }
      if (src.dataset.desc) cap.appendChild(document.createTextNode(src.dataset.desc));
    };
    var open = function (i) { lastFocus = document.activeElement; lb.hidden = false; document.body.style.overflow = 'hidden'; show(i); $('[data-lb-close]', lb).focus(); };
    var close = function () { lb.hidden = true; document.body.style.overflow = ''; if (lastFocus) lastFocus.focus(); };
    items.forEach(function (b, i) { b.addEventListener('click', function () { open(i); }); });
    $('[data-lb-close]', lb).addEventListener('click', close);
    $('[data-lb-prev]', lb).addEventListener('click', function () { show(idx - 1); });
    $('[data-lb-next]', lb).addEventListener('click', function () { show(idx + 1); });
    lb.addEventListener('click', function (e) { if (e.target === lb) close(); });
    document.addEventListener('keydown', function (e) {
      if (lb.hidden) return;
      if (e.key === 'Escape') close();
      else if (e.key === 'ArrowLeft') show(idx - 1);
      else if (e.key === 'ArrowRight') show(idx + 1);
    });
  }
})();

/* Hero video: skip it for people who ask for less motion or less data. */
(function () {
  var v = document.querySelector('.hero-video video');
  if (!v) return;
  var c = navigator.connection || {};
  if (c.saveData || /(^|-)2g$/.test(c.effectiveType || '') || (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches)) {
    v.pause(); v.removeAttribute('autoplay'); v.querySelectorAll('source').forEach(function (s) { s.removeAttribute('src'); }); v.load(); v.parentNode.style.display = 'none';
  }
})();

/* Progressive web app: register the service worker and offer "Install the app". */
(function () {
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    window.addEventListener('load', function () { navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(function () {}); });
  }
  var box = document.querySelector('[data-install]'), btn = document.querySelector('[data-install-btn]'), ios = document.querySelector('[data-install-ios]');
  if (!box) return;
  var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone;
  if (standalone) return;
  var deferred = null;
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; box.hidden = false; });
  window.addEventListener('appinstalled', function () { box.hidden = true; deferred = null; });
  btn.addEventListener('click', function () { if (!deferred) return; deferred.prompt(); deferred.userChoice.finally(function () { deferred = null; box.hidden = true; }); });
  if (/iphone|ipad|ipod/i.test(navigator.userAgent) && !window.MSStream) { box.hidden = false; btn.hidden = true; ios.hidden = false; }
})();

/* Colour theme picker */
(function () {
  var host = document.querySelector('[data-theme-picker]');
  if (!host) return;
  var THEMES = [['lapis', 'Lapis blue', '#17297a'], ['forest', 'Forest green', '#1f5a43'], ['sunrise', 'Sunrise', '#9a4310'], ['rose', 'Rose', '#8a2450'], ['night', 'Night', '#0f1226'], ['auto', 'Match my device', 'linear-gradient(90deg,#f4f2ec 50%,#0f1226 50%)']];
  var def = document.documentElement.getAttribute('data-theme') || 'lapis';
  function saved() { try { return localStorage.getItem('ba-theme') || ''; } catch (e) { return ''; } }
  var btn = document.createElement('button'); btn.type = 'button'; btn.setAttribute('aria-label', 'Change colour theme'); btn.setAttribute('aria-expanded', 'false');
  btn.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 0 0 18z" fill="currentColor"/></svg>';
  var pop = document.createElement('div'); pop.className = 'theme-pop'; pop.hidden = true;
  var h = document.createElement('h2'); h.textContent = 'Colour theme'; pop.appendChild(h);
  function mark() { var cur = saved() || def; [].forEach.call(pop.querySelectorAll('.theme-opt'), function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-t') === cur)); }); }
  THEMES.forEach(function (t) {
    var b = document.createElement('button'); b.type = 'button'; b.className = 'theme-opt'; b.setAttribute('data-t', t[0]);
    var sw = document.createElement('span'); sw.className = 'theme-sw'; sw.style.background = t[2];
    var l = document.createElement('span'); l.textContent = t[1]; b.appendChild(sw); b.appendChild(l);
    b.addEventListener('click', function () {
      try { localStorage.setItem('ba-theme', t[0]); } catch (e) {}
      var v = t[0] === 'auto' ? (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'night' : def) : t[0];
      document.documentElement.setAttribute('data-theme', v); mark();
    });
    pop.appendChild(b);
  });
  btn.addEventListener('click', function (e) { e.stopPropagation(); pop.hidden = !pop.hidden; btn.setAttribute('aria-expanded', String(!pop.hidden)); mark(); });
  document.addEventListener('click', function (e) { if (!host.contains(e.target)) { pop.hidden = true; btn.setAttribute('aria-expanded', 'false'); } });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { pop.hidden = true; btn.focus(); } });
  host.appendChild(btn); host.appendChild(pop); host.hidden = false;
})();
